import logging

__author__ = "Saranraj Nambusubramaniyan"
__version__ = "0.1.2"

logging.basicConfig(level=logging.INFO)
